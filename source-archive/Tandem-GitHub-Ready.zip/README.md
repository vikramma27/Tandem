<div align="center">

<img src="app/src/main/ic_tandem_playstore_512.png" width="112" alt="Tandem app icon" />

# TANDEM
### Two Minds. One Rhythm.

**A shared space for the little things that make life work together.**

[![Android](https://img.shields.io/badge/Platform-Android-3DDC84?logo=android&logoColor=white)](https://www.android.com/)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.0.21-7F52FF?logo=kotlin&logoColor=white)](https://kotlinlang.org/)
[![Jetpack Compose](https://img.shields.io/badge/UI-Jetpack%20Compose-4285F4)](https://developer.android.com/compose)
[![Build APK](https://github.com/vikramma27/Tandem/actions/workflows/build-apk.yml/badge.svg)](https://github.com/vikramma27/Tandem/actions/workflows/build-apk.yml)

[**Explore the immersive 3D project site**](https://vikramma27.github.io/Tandem/) · [**Download latest APK**](https://github.com/vikramma27/Tandem/releases/latest)

</div>

---

## The idea

Tandem is a native Android shared-space app designed around two people coordinating everyday life. Start with a clean solo workspace, configure your identity, and pair with one other person when you're ready.

## What is inside

- **A clean starting point** — no seeded names, sample tasks, or dummy lists.
- **Two-person pairing** — configure your display name and use a `TNDM-XXXX-XXXX` invite code.
- **Shared spaces** — keep activities and lists organised by context.
- **Action tasks** — create, assign, prioritise, and complete tasks.
- **Attention nudges** — send a focused ping when something needs a partner's attention.
- **Smart shopping lists** — organise items by aisle, quantity, store tag, and estimated cost.
- **Shared rituals** — keep recurring check-ins visible for both people.
- **Local-first storage** — Room provides on-device persistence.

> Pairing and relay synchronisation are integration points in the current codebase. A working relay backend must be configured for cross-device data synchronisation; the Android client alone does not host that service.

## Immersive project experience

The companion project site uses a lightweight Three.js scene with an animated orbital motif, depth, lighting, and responsive motion. It is a separate GitHub Pages experience; GitHub's README renderer does not execute embedded JavaScript or arbitrary iframe content.

## Download and install

1. Open [**Latest Releases**](https://github.com/vikramma27/Tandem/releases/latest).
2. Download `app-release-unsigned.apk` (or the release APK asset shown there).
3. On Android, allow installation from the browser or file manager when prompted.
4. Open Tandem.

The automated release APK is currently **unsigned for Play Store distribution**. Android may still allow local installation of an unsigned APK in some workflows, but a production installable release should be signed with a private keystore. Never commit that keystore or its passwords to Git.

## Build it yourself

Requirements:
- JDK 17
- Android SDK with API 35
- Gradle 8.10.2 (the GitHub Actions workflow provisions this)

From the `TandemAndroid` directory:

```bash
gradle assembleDebug
gradle assembleRelease
```

APK outputs:

```text
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Automated builds and releases

- Every push to `main` builds debug and release APKs and uploads them as a workflow artifact.
- Pull requests targeting `main` are built for validation.
- Pushing a version tag such as `v1.0.0` builds both variants and publishes the APKs to a GitHub Release.
- You can also start a build manually from **Actions → Android APK → Run workflow**.

Create a release tag:

```bash
git tag v1.0.0
git push origin v1.0.0
```

## Technology

| Layer | Technology |
|---|---|
| Language | Kotlin 2.0.21 |
| UI | Jetpack Compose + Material 3 |
| Local persistence | Room |
| Async state | Kotlin Coroutines + Flow |
| Serialization | kotlinx.serialization |
| Background work dependency | WorkManager |
| Build | Android Gradle Plugin 8.7.2, JDK 17 |

## Project structure

```text
TandemAndroid/
├── .github/workflows/build-apk.yml
├── app/
│   └── src/main/
│       ├── java/app/tandem/duo/
│       └── res/
├── gradle/libs.versions.toml
├── build.gradle.kts
└── settings.gradle.kts
```

## License

No license file was included in the supplied project archive. All rights remain with the copyright holder until a license is explicitly added.
